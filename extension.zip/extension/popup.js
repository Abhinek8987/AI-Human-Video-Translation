// popup.js - Handles UI and backend API call to /live_translate

const fileInput = document.getElementById('fileInput')
const langSelect = document.getElementById('langSelect')
const translateBtn = document.getElementById('translateBtn')
const progressEl = document.getElementById('progress')
const audioEl = document.getElementById('audio')
const playerWrap = document.getElementById('player')

const BACKEND_URL = 'http://localhost:8000/live_translate'

function show(el) { el.classList.remove('hidden') }
function hide(el) { el.classList.add('hidden') }
function setProgress(msg) { progressEl.textContent = msg }

translateBtn.addEventListener('click', async () => {
  const file = fileInput.files && fileInput.files[0]
  const lang = langSelect.value
  if (!file) {
    setProgress('Please choose a media file first.');
    show(progressEl)
    return
  }

  // Prepare form-data
  const formData = new FormData()
  formData.append('file', file)
  formData.append('lang', lang)

  // Update UI
  setProgress('Translating...')
  show(progressEl)
  hide(playerWrap)
  audioEl.src = ''

  try {
    const resp = await fetch(BACKEND_URL, {
      method: 'POST',
      body: formData,
    })

    if (!resp.ok) {
      throw new Error(`Server error: ${resp.status}`)
    }

    // Response is a binary audio file (mp3/wav)
    const blob = await resp.blob()
    const url = URL.createObjectURL(blob)

    audioEl.src = url
    show(playerWrap)
    setProgress('Done. Playing result...')
    audioEl.play().catch(() => {/* user gesture may be required */})
  } catch (err) {
    console.error(err)
    setProgress('Failed to translate. Make sure backend is running at http://localhost:8000')
  }
})
